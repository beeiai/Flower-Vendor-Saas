// DailySaleView component
