// SaalaView component
