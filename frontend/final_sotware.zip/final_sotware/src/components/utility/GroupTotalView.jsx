// GroupTotalView component
