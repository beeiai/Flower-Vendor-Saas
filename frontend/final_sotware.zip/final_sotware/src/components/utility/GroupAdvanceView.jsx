// GroupAdvanceView component
