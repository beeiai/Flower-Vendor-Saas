// GroupPaymentView component
