// SmsView component
