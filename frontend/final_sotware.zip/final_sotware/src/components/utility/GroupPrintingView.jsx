// GroupPrintingView component
