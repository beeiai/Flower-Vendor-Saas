// RegistryForm component
