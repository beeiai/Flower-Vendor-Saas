import React from 'react';
import { X } from 'lucide-react';

function ItemRegistryForm({ form, setForm, onSave, onCancel }) {
	// ...existing code...
}

export default ItemRegistryForm;
// ItemRegistryForm component
