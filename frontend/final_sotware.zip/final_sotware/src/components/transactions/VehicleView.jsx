// VehicleView component
