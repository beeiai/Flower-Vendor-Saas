// calculation utilities
