// saalaStore logic
