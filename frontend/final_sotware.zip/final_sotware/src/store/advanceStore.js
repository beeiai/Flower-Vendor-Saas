// advanceStore logic
