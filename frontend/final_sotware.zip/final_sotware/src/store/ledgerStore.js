// ledgerStore logic
